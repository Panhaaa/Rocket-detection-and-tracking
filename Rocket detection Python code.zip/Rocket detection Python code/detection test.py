import argparse
import struct
import time
from pathlib import Path
import pickle
import cv2
import torch
import torch.backends.cudnn as cudnn
import serial as ser
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
from random import randrange
from drawnow import*



from numpy import random

from models.experimental import attempt_load
from utils.datasets import LoadStreams, LoadImages
from utils.general import check_img_size, check_requirements, check_imshow, non_max_suppression, apply_classifier, \
    scale_coords, xyxy2xywh, strip_optimizer, set_logging, increment_path
from utils.plots import plot_one_box
from utils.torch_utils import select_device, load_classifier, time_synchronized, TracedModel




ser = ser.Serial(port='COM7', baudrate=115200)

# def sendData(data1, data2):
#     # Combine the two values into a string separated by a comma
#     #data1 is xc
#     #data2 is yc
#     data = str(data1) +',' + str(data2) + '\n'
#     #print(str(data2))

#     # Transmit the data over Serial
#     arduino.write(data.encode())




def sendData(value_x,value_y):
    data1 = bytearray(struct.pack("f",value_x))
    data2 = bytearray(struct.pack("f",value_y))

    for i in data1:
       ser.write(bytes([i]))
    for j in data2:
       ser.write(bytes([j]))
    ser.write(bytes('H','utf-8'))

    # ser.write(0)
    # ser.write(int(value_x - 80 ) % 256)
    # ser.write(0)
    # ser.write(int(value_y -80 ) % 256)
    # ser.write(bytes('H','utf-8'))

    # print(int(value_x -80) % 256)
# plt.ion() 
# def makeFig():
#     plt.xlabel('time')
#     plt.ylabel('Error')
#     plt.title('Error vs time of tracking')
#     plt.plot(M1_e, label ='ErroM1')
#     plt.legend(loc = 'upper right')
#     plt.plot(M2_e, label= 'ErrorM2')
#     plt.legend(loc = 'upper right')

def detect(save_img=False):
    source, weights, view_img, save_txt, imgsz, trace = opt.source, opt.weights, opt.view_img, opt.save_txt, opt.img_size, not opt.no_trace
    save_img = not opt.nosave and not source.endswith('.txt')  # save inference images
    webcam = source.isnumeric() or source.endswith('.txt') or source.lower().startswith(
        ('rtsp://', 'rtmp://', 'http://', 'https://'))

    # Directories
    save_dir = Path(increment_path(Path(opt.project) / opt.name, exist_ok=opt.exist_ok))  # increment run
    (save_dir / 'labels' if save_txt else save_dir).mkdir(parents=True, exist_ok=True)  # make dir

    # Initialize
    set_logging()
    device = select_device(opt.device)
    half = device.type != 'cpu'  # half precision only supported on CUDA

    # Load model
    model = attempt_load(weights, map_location=device)  # load FP32 model
    stride = int(model.stride.max())  # model stride
    imgsz = check_img_size(imgsz, s=stride)  # check img_size

    if trace:
        model = TracedModel(model, device, opt.img_size)

    if half:
        model.half()  # to FP16

    # Second-stage classifier
    classify = False
    if classify:
        modelc = load_classifier(name='resnet101', n=2)  # initialize
        modelc.load_state_dict(torch.load('weights/resnet101.pt', map_location=device)['model']).to(device).eval()

    # Set Dataloader
    vid_path, vid_writer = None, None
    if webcam:
        view_img = check_imshow()
        cudnn.benchmark = True  # set True to speed up constant image size inference
        dataset = LoadStreams(source, img_size=imgsz, stride=stride)
    else:
        dataset = LoadImages(source, img_size=imgsz, stride=stride)

    # Get names and colors
    names = model.module.names if hasattr(model, 'module') else model.names
    colors = [[random.randint(0, 255) for _ in range(3)] for _ in names]

    # Run inference
    if device.type != 'cpu':
        model(torch.zeros(1, 3, imgsz, imgsz).to(device).type_as(next(model.parameters())))  # run once
    old_img_w = old_img_h = imgsz
    old_img_b = 1

    t0 = time.time()
    M1_e = []
    M2_e = []
    #initial poistion of gimbal
    for path, img, im0s, vid_cap in dataset:
        img = torch.from_numpy(img).to(device)
        img = img.half() if half else img.float()  # uint8 to fp16/32
        img /= 255.0  # 0 - 255 to 0.0 - 1.0
        if img.ndimension() == 3:
            img = img.unsqueeze(0)

        # Warmup
        if device.type != 'cpu' and (old_img_b != img.shape[0] or old_img_h != img.shape[2] or old_img_w != img.shape[3]):
            old_img_b = img.shape[0]
            old_img_h = img.shape[2]
            old_img_w = img.shape[3]
            for i in range(3):
                model(img, augment=opt.augment)[0]

        # Inference
        t1 = time_synchronized()
        with torch.no_grad():  # Calculating gradients would cause a GPU memory leak
            pred = model(img, augment=opt.augment)[0]
        t2 = time_synchronized()

        # Apply NMS
        pred = non_max_suppression(pred, opt.conf_thres, opt.iou_thres, classes=opt.classes, agnostic=opt.agnostic_nms)
        t3 = time_synchronized()

        # Apply Classifier
        if classify:
            pred = apply_classifier(pred, modelc, img, im0s)
        
        #initial pos for gimbal

        M1 = 90 
        M2 = 90
    
        # Process detections
        # M1_e = []
        # M2_e = []
        # print("===list")
        # print(M1_e,M2_e)

        print('Start 2')
        for i, det in enumerate(pred):  # detections per image
            if webcam:  # batch_size >= 1
                p, s, im0, frame = path[i], '%g: ' % i, im0s[i].copy(), dataset.count
            else:
                p, s, im0, frame = path, '', im0s, getattr(dataset, 'frame', 0)

            p = Path(p)  # to Path
            save_path = str(save_dir / p.name)  # img.jpg
            txt_path = str(save_dir / 'labels' / p.stem) + ('' if dataset.mode == 'image' else f'_{frame}')  # img.txt
            gn = torch.tensor(im0.shape)[[1, 0, 1, 0]]  # normalization gain whwh

            if len(det):
                # webcam resolution
                w, h = im0.shape[1], im0.shape[0]

                # Rescale boxes from img_size to im0 size
                det[:, :4] = scale_coords(img.shape[2:], det[:, :4], im0.shape).round()

                # extract bbox
                det = det.cpu().numpy()[0]
                xyxy, conf, label = det[:4], det[4], det[5]

                # find center of bbox
                xc = (xyxy[2] + xyxy[0]) / 2
                yc = (xyxy[3] + xyxy[1]) / 2

                # calculate Error of M1 and M2
                ErrorM1 = xc - w/2
                ErrorM2 = yc - h/2
                
                print("================================================================")
                print(ErrorM1, ErrorM2)
                sendData(ErrorM1,ErrorM2)
                

                #calculate of bounding box
                Area = w*h
                # calculate M1 and M2 by using controller and make it stand on the same point
                M1 = M1 + ErrorM1/66
                M2 = M2 + ErrorM2/62

                # limitation
                if M1 > 360:
                    M1 =360
                    print('M1 is out of range!')
                if M2 > 360:
                    M2 = 360
                    print('M2 is out of range!')
                if M1 < 0:
                    M1 = 0
                    print('M1 is out of range!')
                if M2 < 0:
                    M2 = 0
                    print('M2 is out of range!')

                im0 = cv2.putText(im0, str(conf), (int(xyxy[0]), int(xyxy[1]) - 5), cv2.FONT_HERSHEY_SIMPLEX, 0.5,
                                  (255, 0, 0), 1)#img0 is the frame
                im0 = cv2.circle(im0, (int(w / 2), int(h / 2)), 3, (0, 0, 255), -1) #-1 is thickness,
                im0 = cv2.circle(im0, (int(xc), int(yc)), 3, (255, 0, 0), -1) #
                im0 = cv2.rectangle(im0, (int(xyxy[0]), int(xyxy[1])), (int(xyxy[2]), int(xyxy[3])), (255, 0, 0), 2)

                M1_e.append(ErrorM1)
                M2_e.append(ErrorM2)
                #drawnow(makeFig)
                #plt.pause(.000001)

                print(M1_e,M2_e)
                y = len(M1_e)
                if y < 150:
                    with open("M1_e", "wb") as fp:   #Pickling  
                        pickle.dump(M1_e, fp)
                    with open("M2_e", "wb") as fp:   #Pickling  
                        pickle.dump(M2_e, fp)
            
            # Stream results
            if view_img:
                cv2.imshow(str(p), im0)
                cv2.waitKey(1)  # 1 millisecond


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--weights', nargs='+', type=str, default='runs/train/exp110/weights/best.pt',help='model.pt path(s)')
    parser.add_argument('--source', type=str, default='0', help='source')  # file/folder, 0 for webcam
    parser.add_argument('--img-size', type=int, default=640, help='inference size (pixels)')
    parser.add_argument('--conf-thres', type=float, default=0.25, help='object confidence threshold')
    parser.add_argument('--iou-thres', type=float, default=0.45, help='IOU threshold for NMS')
    parser.add_argument('--device', default='', help='cuda device, i.e. 0 or 0,1,2,3 or cpu')
    parser.add_argument('--view-img', action='store_true', help='display results')
    parser.add_argument('--save-txt', action='store_true', help='save results to *.txt')
    parser.add_argument('--save-conf', action='store_true', help='save confidences in --save-txt labels')
    parser.add_argument('--nosave', action='store_true', default=True, help='do not save images/videos')
    parser.add_argument('--classes', nargs='+', type=int, help='filter by class: --class 0, or --class 0 2 3')
    parser.add_argument('--agnostic-nms', action='store_true', help='class-agnostic NMS')
    parser.add_argument('--augment', action='store_true', help='augmented inference')
    parser.add_argument('--update', action='store_true', help='update all models')
    parser.add_argument('--project', default='runs/detect', help='save results to project/name')
    parser.add_argument('--name', default='exp', help='save results to project/name')
    parser.add_argument('--exist-ok', action='store_true', help='existing project/name ok, do not increment')
    parser.add_argument('--no-trace', action='store_true', help='don`t trace model')
    opt = parser.parse_args()
    print(opt)
    # check_requirements(exclude=('pycocotools', 'thop'))
    with torch.no_grad():
        if opt.update:  # update all models (to fix SourceChangeWarning)
            for opt.weights in ['yolov7.pt']:
                detect()
                strip_optimizer(opt.weights)
        else:
            detect()