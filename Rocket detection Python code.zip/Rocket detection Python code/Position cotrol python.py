import serial
import time

arduino = serial.Serial(port='COM5', baudrate=115200, timeout=.1)

def write_read(x):    
    # append the letter T to the user input
    x = "T" 
    # encode the string x to bytes and add a newline character
    x = x.encode() + b"\n"
    # write the bytes data to Arduino
    arduino.write(x)
    # wait for 0.05 seconds
    time.sleep(0.05)
    # read a line of data from Arduino
    data = arduino.readline()
    # decode the bytes data to string and strip the newline character
    data = data.decode().strip()
    # print the sent and received data
    print(f"Sent: {x}, Received: {data}")
    # return the received data
    return data

while True:
    # get user input
    num = input("Enter a number: ")
    # check if the user wants to exit
    if num == "exit":
        break
    # otherwise, call the write_read function with the user input
    else:
        value = write_read(num)
        print(value)