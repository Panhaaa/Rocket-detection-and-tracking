import matplotlib.pyplot as plt
import numpy as np
from drawnow import *
import time
import cv2

import pickle

with open("M1_e", "rb") as fp:   # Unpickling
    M1 = pickle.load(fp)
with open("M2_e", "rb") as fp:   # Unpickling
    M2 = pickle.load(fp)
plt.grid(True)
plt.xlabel('time')
plt.ylabel('Error(px)')
plt.title('Error vs time of live tracking')
#plt.plot(M1, label='Error_x')
plt.legend(loc='upper right')
plt.plot(M2, label='Error_y')
plt.legend(loc='upper right')
plt.show()

    